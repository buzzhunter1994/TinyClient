
CONVERSION ERROR: Code could not be converted. Details:

-- line 169 col 36: this symbol not expected in EndOfStmt

Please check for any errors in the original code and try again.
