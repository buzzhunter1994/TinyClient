﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace AniScrollViewerExample
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private const int _ITEM_COUNT = 20;
        public Window1()
        {
            InitializeComponent();
            //Create some buttons ;)
            for (int i = 0; i < _ITEM_COUNT; i++)
            {
                Button btn = CreateButton(i);
                ListViewItem item = new ListViewItem();
                item.Tag=btn;
                item.Content="Button " + i.ToString();
                cbJumpTo.Items.Add(item);
                mainContent.Children.Add(btn);
            }
        }

        /// <summary>
        /// Create a new button...  There are some properties that need to be set, since this is a 
        /// SIMPLE demo, this should be fine.
        /// </summary>
        /// <param name="index">index of the button</param>
        /// <returns>Created button</returns>
        private Button CreateButton(int index)
        {
            Button btn = new Button();
            btn.Content = "Button " + index.ToString();
            btn.Height = 30;
            btn.Margin = new Thickness(5);
            return btn;
        }
        /// <summary>
        /// Animate the scrollviewer the the selected item from the combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAnimate_Click(object sender, RoutedEventArgs e)
        {
            //Get the position of the button located in the tag
            Button btn = ((ListViewItem)cbJumpTo.SelectedItem).Tag as Button;
            Point relativePoint = btn.TransformToAncestor(mainContent).Transform(new Point(0, 0));
            ScrollToPosition(relativePoint.X, relativePoint.Y);
        }

        /// <summary>
        /// Create a new animation to the x,y offset.  I beleive you need the have .NET 3.5 SP1 installed for
        /// this to work.  If you don't you can't call Storyboard.SetTarget.
        /// </summary>
        /// <param name="x">X position</param>
        /// <param name="y">Y position</param>
        private void ScrollToPosition(double x, double y)
        {
            DoubleAnimation vertAnim = new DoubleAnimation();
            vertAnim.From = mainViewer.VerticalOffset;
            vertAnim.To = y;
            vertAnim.DecelerationRatio = .2;
            vertAnim.Duration = new Duration(TimeSpan.FromMilliseconds(1000));
            DoubleAnimation horzAnim = new DoubleAnimation();
            horzAnim.From = mainViewer.HorizontalOffset;
            horzAnim.To = x;
            horzAnim.DecelerationRatio = .2;
            horzAnim.Duration = new Duration(TimeSpan.FromMilliseconds(1000));
            Storyboard sb = new Storyboard();
            sb.Children.Add(vertAnim);
            sb.Children.Add(horzAnim);
            Storyboard.SetTarget(vertAnim, mainViewer);
            Storyboard.SetTargetProperty(vertAnim, new PropertyPath(AniScrollViewer.CurrentVerticalOffsetProperty));
            Storyboard.SetTarget(horzAnim, mainViewer);
            Storyboard.SetTargetProperty(horzAnim, new PropertyPath(AniScrollViewer.CurrentHorizontalOffsetProperty));
            sb.Begin();
        }


}

      }